<?php
declare(strict_types=1);

namespace AgVote\Service;

use AgVote\Repository\MeetingRepository;
use AgVote\Repository\MotionRepository;

/**
 * MeetingValidator
 *
 * Objectif: centraliser la logique "prêt à valider / signer".
 *
 * Règles (cahier des charges v1.0):
 * - aucune motion ouverte
 * - toutes les motions fermées ont un résultat exploitable:
 *    - soit un comptage manuel cohérent (manual_total > 0 et somme == total)
 *    - soit au moins un bulletin e-vote (ballots)
 * - le Président (nom) est renseigné
 * - (optionnel) consolidation effectuée: official_source présent sur toutes les motions fermées
 */

final class MeetingValidator
{
    public static function canBeValidated(string $meetingId, string $tenantId): array
    {
        $meetingRepo = new MeetingRepository();
        $meeting = $meetingRepo->findByIdForTenant($meetingId, $tenantId);

        if (!$meeting) {
            return [
                'can' => false,
                'reasons' => ['Séance introuvable.'],
                'metrics' => [],
            ];
        }

        $reasons = [];
        $codes = [];

        if (trim((string)($meeting['president_name'] ?? '')) === '') {
            $reasons[] = 'Président non renseigné.';
            $codes[] = 'missing_president';
        }

        $motionRepo = new MotionRepository();

        $open = $meetingRepo->countOpenMotions($meetingId);
        if ($open > 0) {
            $reasons[] = "$open motion(s) encore ouverte(s).";
            $codes[] = 'open_motions';
        }

        $bad = $motionRepo->countBadClosedMotions($meetingId);
        if ($bad > 0) {
            $reasons[] = "$bad motion(s) fermée(s) sans résultat exploitable (manuel cohérent ou e-vote).";
            $codes[] = 'bad_closed_results';
        }

        $closed = $meetingRepo->countClosedMotions($meetingId);
        $consolidated = $motionRepo->countConsolidatedMotions($meetingId);

        // On exige la consolidation dès qu'il y a au moins une motion fermée.
        $needsConsolidation = $closed > 0;
        $consolidationDone = (!$needsConsolidation) || ($consolidated >= $closed);
        if ($needsConsolidation && !$consolidationDone) {
            $reasons[] = 'Consolidation non effectuée (résultats officiels non persistés).';
            $codes[] = 'consolidation_missing';
        }

        return [
            'can' => count($reasons) === 0,
            'codes' => $codes,
            'reasons' => $reasons,
            'metrics' => [
                'open_motions' => $open,
                'bad_closed_motions' => $bad,
                'closed_motions' => $closed,
                'consolidated_motions' => $consolidated,
                'consolidation_done' => $consolidationDone,
            ],
        ];
    }
}
