<?php
// public/api/v1/admin_reset_demo.php
// Alias for meeting_reset_demo.php — admin.htmx.html references this name
require __DIR__ . '/meeting_reset_demo.php';
