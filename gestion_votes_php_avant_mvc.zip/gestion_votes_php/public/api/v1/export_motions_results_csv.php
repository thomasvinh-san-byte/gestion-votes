<?php
declare(strict_types=1);

/**
 * Export CSV des résultats des résolutions
 *
 * Génère un fichier CSV avec les résultats de vote de chaque résolution
 * formaté en français pour utilisation directe dans Excel ou autre tableur.
 *
 * Disponible uniquement après validation de la séance.
 */

require __DIR__ . '/../../../app/api.php';

use AgVote\Repository\MeetingRepository;
use AgVote\Repository\MotionRepository;
use AgVote\Service\ExportService;

api_require_role(['operator', 'admin', 'auditor']);

$meetingId = trim((string)($_GET['meeting_id'] ?? ''));
if ($meetingId === '' || !api_is_uuid($meetingId)) {
    api_fail('missing_meeting_id', 400);
}

// Exports autorisés uniquement après validation (exigence conformité)
$meetingRepo = new MeetingRepository();
$mt = $meetingRepo->findByIdForTenant($meetingId, api_current_tenant_id());
if (!$mt) api_fail('meeting_not_found', 404);
if (empty($mt['validated_at'])) api_fail('meeting_not_validated', 409);

// Génération du fichier
$filename = ExportService::generateFilename('resultats', $mt['title'] ?? '');
ExportService::initCsvOutput($filename);

$out = ExportService::openCsvOutput();

// En-têtes français
ExportService::writeCsvRow($out, ExportService::getMotionResultsHeaders());

// Données formatées
$motionRepo = new MotionRepository();
$rows = $motionRepo->listResultsExportForMeeting($meetingId);

foreach ($rows as $r) {
    ExportService::writeCsvRow($out, ExportService::formatMotionResultRow($r));
}

fclose($out);
