from django.apps import AppConfig

class HeliosConfig(AppConfig):
    name = 'helios'
    verbose_name = "Helios"
