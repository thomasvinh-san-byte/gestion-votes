The Helios Django App
=====================

LICENSE: this code is released under the GPL v3 or later.

NOTE: this used to be a separate git submodule, but now it's not.
