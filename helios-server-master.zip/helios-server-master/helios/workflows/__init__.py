"""
Helios Election Workflows
"""

from helios.datatypes import LDObjectContainer

class WorkflowObject(LDObjectContainer):
    pass
    
